/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ProductServices;

import java.util.*;
import models.Producto;
import store.DataBase;
/**
 *
 * @author plopez
 */
public class ProductServices {
    
    private DataBase dBase;
    
    public ProductServices(String path) throws Exception {
        dBase = new DataBase(path);
    }
    
    public Producto Insertar(Producto model) throws Exception {
        
        if (model.getImporte()<= 0)
            throw new Exception("Importe de Produco Invalido") ;
                
        return dBase.Insertar(model);
    }

    public Producto Modificar(Producto model) throws Exception {
        
        if (model.getId() <= 0)
            throw new Exception("Codigo de Produco Invalido") ;
                
        return dBase.Modificar(model);
    }
    
    public void Eliminar(Integer id) throws Exception {
        
        if (id <= 0)
            throw new Exception("ID de Produco Invalido") ;
                
        dBase.Eliminar(id);
    }

    public List<Producto> GetProducts() throws Exception {
        return dBase.GetProducts();
    }
    
    public Producto GetProduct(int id) throws Exception{
        
        if (id <= 0)
            throw new Exception("Codigo de Produco Invalido");
                
        return dBase.GetProduct(id);
    }
}
