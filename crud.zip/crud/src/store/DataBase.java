/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package store;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import models.Producto;
/**
 *
 * @author plopez
 */
public class DataBase {
    private static Connection conn;
    //private static final String URL = "jdbc:ucanaccess://C:/prueba/Database11.accdb";
    
    public DataBase(String path) throws Exception {
        try {
            if (conn == null) {
                conn =  DriverManager.getConnection("jdbc:ucanaccess://" + path);
            }
        } catch (Exception e) {
            throw new Exception("No fue posible conectar la base de datos");
        }
    }

    public Producto Insertar(Producto p) throws Exception {
        Statement stm = null;
        String query = "Insert Into Productos (descripcion, importe) Values ('" + p.getDescripcion() + "'," +  p.getImporte() + ")";        
        
        try{
            stm = conn.createStatement();
            stm.executeUpdate(query);            
        }
        catch (Exception e){
            throw new Exception("Error al Insertar datos");
        }
        return p;
    }    
    
    public void Eliminar(Integer id) throws Exception {
        Statement stm = null;
        String query = "Delete From Productos Where ID=" + id.toString();
        
        try{
            stm = conn.createStatement();
            stm.executeUpdate(query);
        }
        catch (Exception e){
            throw new Exception("Error al eliminar datos");
        }        
    }
    
    public Producto Modificar(Producto p) throws Exception {
        Statement stm = null;
        String query = "Update Productos SET descripcion= '" + p.getDescripcion() + "' , importe =" + p.getImporte() + " Where ID=" + p.getId();        
        try{
            stm = conn.createStatement();
            stm.executeUpdate(query);
        }
        catch (Exception e){
            throw new Exception("Error al modificar datos");
        }
        return p;
    }
    
    public List<Producto> GetProducts() throws Exception{
        List<Producto> prods = new ArrayList<>();
        Statement stm = null;
        String query = "Select * from Productos";
        
        try {
            stm = conn.createStatement();
            ResultSet rs = stm.executeQuery(query);
            while (rs.next()) {
                Producto p = new Producto();
                p.setDescripcion(rs.getString("descripcion"));
                p.setImporte(Double.parseDouble(rs.getString("importe")));
                p.setId(Integer.parseInt(rs.getString("id")));
                prods.add(p);
            }        
        } catch (Exception e) {
            throw new Exception("No fue posible realizar la consulta a base de datos");
        }
        return prods;
    }
    
    public Producto GetProduct(int id) throws Exception{
        Statement stm = null;
        String query = "Select * from Productos WHERE id = " + id;
        
        try {
            stm = conn.createStatement();
            ResultSet rs = stm.executeQuery(query);
            while (rs.next()) {
                Producto p = new Producto();
                p.setDescripcion(rs.getString("descripcion"));
                p.setImporte(Double.parseDouble(rs.getString("importe")));
                p.setId(Integer.parseInt(rs.getString("id")));
                return p;
            }        
        } catch (Exception e) {
            throw new Exception("No fue posible realizar la consulta a base de datos");
        }
        return null;
    }
    
    public void Desconectar() {
        try {
            conn.close();
        } catch (Exception e) {
            System.out.println("No fue posible cerrar la conexion a la base de datos");
        }
    }       
}
